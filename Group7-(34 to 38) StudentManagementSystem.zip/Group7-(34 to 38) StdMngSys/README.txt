This was a project submitted by the Group 7 of Department of Mechatronics 
Engineering from RUET.
The group members were from Roll : 1908034 to Roll : 1908038.

The project was to make Student Management System for Course Adviser.

To see the code, Unzip the StudentManagementSystem.zip file and 
run Netbeans with Java 17 IDE.
For Database use Xampp.

All the required application are already noted in "Requirements".

Due to errors while trying to make .exe file we couldn't provide any executable or installation file.

