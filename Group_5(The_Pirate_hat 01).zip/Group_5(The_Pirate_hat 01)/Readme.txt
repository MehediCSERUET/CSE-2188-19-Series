The Pirate Hat is a 2D platformer game.It's one kind of sub action game.

Features of the game:

1.Player can control ‘the pirate’ character who can jump and move in both directions. 
2.The game is separated in 6 complete levels. Each level has to be completed to reach the next level.
3.There are various obstacles such as trees, boxes, water and moving enemies.
4.There is health bar, coin collection indicator and current health display of the player.
5.Audio and sound effects